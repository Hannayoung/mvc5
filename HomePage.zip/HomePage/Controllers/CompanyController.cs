﻿using HomePage.Domain.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomePage.Controllers
{
    public class CompanyController : Controller
    {
        private IProductRepository repository;
        // GET: Product
        public CompanyController(IProductRepository productRepository)
        {
            repository = productRepository;
        }
        // GET: Company
        public ActionResult Introduce()
        {
            return View(repository.Products);
        }

        //더보기 클릭시
        public ActionResult MoreLook()
        {
            return View(repository.Products);
        }

        public ActionResult map()
        {
            return View();
        }

    }
}