﻿using HomePage.Domain.Abstract;
using HomePage.Domain.Entities;
using HomePage.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomePage.Controllers
{
    
    public class ProductController : Controller
    {
        private IProductRepository repository;
        // GET: Product
        public ProductController(IProductRepository productRepository)
        {
            repository = productRepository;
        }

        // GET: Product
        public ActionResult Where(int id = 1)
        {
            if(id == 1)
            {
                return RedirectToAction("MES");
            }
            else if (id == 2)
            {
                return RedirectToAction("ERP");
            }
            else
            {
                return RedirectToAction("Chojungjongmul");
            }
            

        }
        
        public ActionResult MES ()
        {
            return View(repository.Products);
        }
        
        public ActionResult ERP()
        {
            return View(repository.Products);
        }
        
        public ActionResult Chojungjongmul()
        {
            return View(repository.Products);
        }


        //[Route("Product/{id:int}", Name = "IntroduceProducts")]
        //// GET: Product
        //public ActionResult ProductView(int productId = 1)
        //{
        //    if (productId == 1)
        //    {

        //    }
        //    else if (productId == 2)
        //    {

        //    }
        //    else
        //    {

        //    }
        //    return View(repository.Products);

        //}

        public PartialViewResult SmallMenu()
        {
            return PartialView();
        }

        //public ActionResult ProductView()
        //{
        //    return View(repository.Products);
        //}
    }
}