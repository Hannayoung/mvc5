﻿using HomePage.Domain.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomePage.Controllers
{
    public class FaqController : Controller
    {
        private IProductRepository repository;
        // GET: Product
        public FaqController(IProductRepository productRepository)
        {
            repository = productRepository;
        }
        // GET: Faq
        public ActionResult Faq()
        {
            return View(repository.Products);
        }
    }
}