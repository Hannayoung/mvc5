﻿using HomePage.Domain.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomePage.Controllers
{
    public class DownloadController : Controller
    {
        
        private IProductRepository repository;
        // GET: Product
        public DownloadController(IProductRepository productRepository)
        {
            repository = productRepository;
        }
        // GET: Download
        
        public ActionResult Download(string menuid = "1")
        {
            if (menuid == "1")
            {
                ViewBag.menuID = "1";
            }
            else if (menuid == "2")
            {
                ViewBag.menuID = "2";
            }
            else
            {
                ViewBag.menuID = "3";
            }
            return View(repository.Products);
        }


        public PartialViewResult MenuIcon ()
        {
            return PartialView();
        }
       
        public PartialViewResult ManualMenu()
        {
            return PartialView();
        }

        public PartialViewResult DriverMenu()
        {
            return PartialView();
        }

        public PartialViewResult ExeMenu()
        {
            return PartialView();
        }
    }
}