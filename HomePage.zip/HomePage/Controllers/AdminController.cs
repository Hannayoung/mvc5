﻿using HomePage.Domain.Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HomePage.Controllers
{
    public class AdminController : Controller
    {
        private IProductRepository repository;
        // GET: Product
        public AdminController(IProductRepository productRepository)
        {
            repository = productRepository;
        }
        // GET: Admin
        public ActionResult Login()
        {
            return View(repository.Products);
        }
    }
}