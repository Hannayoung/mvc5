﻿using HomePage.Domain.Entities;

using System.Data.Entity;


namespace HomePage.Domain.Concrete
{
    public class EFDbContexts : DbContext
    {
        //public DbSet<MenuProduct> MenuProducts { get; set; }
        public DbSet<Product> Products { get; set; }

    }
}
