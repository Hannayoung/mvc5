﻿using HomePage.Domain.Abstract;
using HomePage.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomePage.Domain.Concrete
{
    public class EFProductRepository : IProductRepository
    {
        private EFDbContexts context = new EFDbContexts();
        
        public IEnumerable<Product> Products
        {
            get { return context.Products; }
        }
        public void SaveProduct(Product product)
        {
            if (product.ProductID == 0)
            {
                context.Products.Add(product);
            }
            else
            {
                //ProductID와 일치하는 객체를 가져옴
               Product dbEntry = context.Products.Find(product.ProductID);
                
                    //그 객체의 설정을 변경
                    dbEntry.Name = product.Name;
                
            }
            //변경한 사항을 적용
            context.SaveChanges();
        }

        public Product DeleteProduct(int productID)
        {
            Product dbEntry = context.Products.Find(productID);

            if (dbEntry != null)
            {
                context.Products.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
